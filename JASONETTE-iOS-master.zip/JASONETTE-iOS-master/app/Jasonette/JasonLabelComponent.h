//
//  JasonLabelComponent.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonHelper.h"
#import <TTTAttributedLabel/TTTAttributedLabel.h>
#import "JasonComponent.h"

@interface JasonLabelComponent : JasonComponent
@end
