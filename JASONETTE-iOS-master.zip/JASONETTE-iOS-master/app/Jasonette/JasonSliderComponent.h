//
//  JasonSliderComponent.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonComponent.h"
#import "JasonComponentFactory.h"

@interface JasonSliderComponent : JasonComponent
@end
