//
//  JASONResponseSerializer.h
//  Jasonette
//
//  Created by e on 7/12/17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface JASONResponseSerializer : AFJSONResponseSerializer

@end
