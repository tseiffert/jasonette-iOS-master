//
//  JasonTimerAction.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonAction.h"
@interface JasonTimerAction : JasonAction <UINavigationControllerDelegate>
@end
