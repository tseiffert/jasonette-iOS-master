//
//  JasonConvertAction.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonAction.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import <JSCoreBom/JSCoreBom.h>
@interface JasonConvertAction : JasonAction
@end
