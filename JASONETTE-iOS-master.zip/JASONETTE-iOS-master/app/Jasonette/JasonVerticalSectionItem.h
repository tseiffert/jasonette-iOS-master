//
//  JasonVerticalSectionItem.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "JasonHelper.h"
#import <SWTableViewCell/SWTableViewCell.h>
@interface JasonVerticalSectionItem : SWTableViewCell

@end
