//
//  JasonVisionAction.h
//  Jasonette
//
//  Created by e on 10/25/17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import "JasonAction.h"
#import "JasonVisionService.h"
#import "Jason.h"

@interface JasonVisionAction : JasonAction

@end
