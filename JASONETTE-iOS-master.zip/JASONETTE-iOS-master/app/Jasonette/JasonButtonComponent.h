//
//  JasonButtonComponent.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonComponent.h"
#import "Jason.h"
#import "NoPaddingButton.h"
#import "JasonLabelComponent.h"

@interface JasonButtonComponent : JasonComponent
@end
