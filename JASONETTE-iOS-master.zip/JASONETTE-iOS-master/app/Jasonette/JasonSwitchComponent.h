//
//  JasonSwitchComponent.h
//  Jasonette
//
//  Created by Camilo Castro on 13-10-17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import "JasonComponent.h"
#import "JasonComponentFactory.h"

@interface JasonSwitchComponent : JasonComponent

@end
