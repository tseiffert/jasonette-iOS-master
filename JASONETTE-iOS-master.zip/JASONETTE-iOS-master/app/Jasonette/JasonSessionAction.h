//
//  JasonSessionAction.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonAction.h"

@interface JasonSessionAction : JasonAction

@end
