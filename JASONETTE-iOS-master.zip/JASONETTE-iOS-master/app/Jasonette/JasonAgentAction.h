//
//  JasonAgentAction.h
//  Jasonette
//
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import "JasonAction.h"

@interface JasonAgentAction : JasonAction

@end
