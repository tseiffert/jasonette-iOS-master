//
//  Constants.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//



#ifndef Constants_h
#define Constants_h


#endif /* Constants_h */

//#define PUSH 1
//#define ADS 1
