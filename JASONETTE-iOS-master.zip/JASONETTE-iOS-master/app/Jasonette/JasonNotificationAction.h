//
//  JasonNotificationAction.h
//  Jasonette
//
//  Created by Unknower on 11/6/16.
//  Copyright © 2016 Jasonette. All rights reserved.
//

#import "JasonAction.h"
#import "JasonHelper.h"

@interface JasonNotificationAction : JasonAction

@end
